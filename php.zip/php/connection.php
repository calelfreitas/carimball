<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "carimball";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Conexão falhou. Erro: " . mysqli_connect_error());
}
?>
